package com.SimCity.SimCity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimCityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimCityApplication.class, args);
	}

}
